﻿
namespace FTCCompiler.Parsing.Common
{
    interface IGenerable
    {
        string GetCode();
    }
}
