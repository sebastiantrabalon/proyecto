﻿
namespace FTCCompiler.Parsing.Common
{
    public interface IPrintable
    {
    }
}
